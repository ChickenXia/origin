![logo](images/mall.svg)

# mall-learning

> mall学习教程，架构、业务、技术要点全方位解析。

mall项目是一套电商系统，使用现阶段主流技术实现。  
涵盖了SpringBoot2.1.3、MyBatis3.4.6、Elasticsearch6.2.2、  
RabbitMQ3.7.15、Redis3.2、Mongodb3.2、Mysql5.7等技术，  
采用Docker容器化部署。

[GitHub](https://github.com/macrozheng/mall-learning)
[Get Started](README.md)
